import React, { useState } from 'react';
import Reveal from './Reveal';
import { Phone, Mail, MapPin, Send, Check, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Contact: React.FC = () => {
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');
    // Simulate API call
    setTimeout(() => {
      setFormStatus('success');
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 bg-white relative overflow-hidden">
      {/* Background blobs */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 bg-brand-blue/20 rounded-full blur-[100px] -z-10" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-brand-beige/80 rounded-full blur-[80px] -z-10" />

      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          
          {/* Contact Info */}
          <div>
            <Reveal>
              <h2 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 mb-6">Get In Touch</h2>
              <p className="text-lg text-slate-600 mb-12 max-w-md">
                Ready to refresh your furniture? Contact us today for a booking or inquiry. We are here to help.
              </p>
            </Reveal>

            <div className="space-y-6">
              <Reveal delay={0.1}>
                <div className="flex items-center gap-6 p-6 rounded-3xl bg-brand-beige/50 border border-brand-beige hover:bg-brand-beige transition-colors">
                  <div className="w-14 h-14 bg-brand-navy rounded-2xl flex items-center justify-center text-white shrink-0 shadow-lg shadow-brand-navy/20">
                    <MapPin size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">Service Area</h4>
                    <div className="inline-flex items-center px-3 py-1 rounded-full bg-brand-blue/30 text-brand-navy text-xs font-bold uppercase tracking-wide">
                        Klang Only
                    </div>
                  </div>
                </div>
              </Reveal>

              <Reveal delay={0.2}>
                <a href="tel:+60115510571" className="flex items-center gap-6 p-6 rounded-3xl bg-brand-beige/50 border border-brand-beige hover:bg-brand-beige transition-colors group">
                  <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-brand-navy shrink-0 shadow-sm group-hover:scale-110 transition-transform">
                    <Phone size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">Phone</h4>
                    <p className="text-slate-600 font-medium group-hover:text-brand-navy transition-colors">011-551-0571</p>
                  </div>
                </a>
              </Reveal>

              <Reveal delay={0.3}>
                <a href="mailto:vimascleaningservices@gmail.com" className="flex items-center gap-6 p-6 rounded-3xl bg-brand-beige/50 border border-brand-beige hover:bg-brand-beige transition-colors group">
                  <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-brand-navy shrink-0 shadow-sm group-hover:scale-110 transition-transform">
                    <Mail size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">Email</h4>
                    <p className="text-slate-600 font-medium group-hover:text-brand-navy transition-colors break-all">vimascleaningservices@gmail.com</p>
                  </div>
                </a>
              </Reveal>

               <Reveal delay={0.4}>
                <a href="https://wa.me/60115510571" target="_blank" className="flex items-center gap-6 p-6 rounded-3xl bg-green-50 border border-green-100 hover:bg-green-100 transition-colors group cursor-pointer">
                  <div className="w-14 h-14 bg-green-500 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-lg shadow-green-500/20 group-hover:scale-110 transition-transform">
                    <MessageSquare size={24} />
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">WhatsApp</h4>
                    <p className="text-slate-600 font-medium group-hover:text-green-700 transition-colors">Chat with us now</p>
                  </div>
                </a>
              </Reveal>
            </div>
          </div>

          {/* Contact Form */}
          <Reveal delay={0.2} className="h-full">
            <div className="bg-white rounded-[2.5rem] p-8 md:p-12 shadow-2xl shadow-slate-200 border border-slate-100 relative overflow-hidden">
                <AnimatePresence mode="wait">
                    {formStatus === 'success' ? (
                        <motion.div 
                            key="success"
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="absolute inset-0 flex flex-col items-center justify-center bg-white z-20"
                        >
                            <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-6 animate-bounce">
                                <Check size={48} />
                            </div>
                            <h3 className="text-3xl font-bold text-slate-900 mb-3">Message Sent!</h3>
                            <p className="text-slate-600 text-center max-w-xs mb-8">We have received your inquiry and will get back to you shortly.</p>
                            <button 
                                onClick={() => setFormStatus('idle')}
                                className="px-8 py-3 rounded-xl bg-slate-100 text-slate-700 font-semibold hover:bg-slate-200 transition-colors"
                            >
                                Send another
                            </button>
                        </motion.div>
                    ) : (
                        <motion.form 
                            key="form"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onSubmit={handleSubmit} 
                            className="space-y-6 relative z-10"
                        >
                            <div className="mb-2">
                                <h3 className="text-2xl font-heading font-bold text-slate-900">Send us a Message</h3>
                                <div className="h-1 w-20 bg-brand-navy rounded-full mt-2"></div>
                            </div>
                            
                            <div className="space-y-5">
                                <div className="relative group">
                                    <input 
                                        type="text" 
                                        id="name"
                                        required 
                                        className="peer w-full px-5 py-4 rounded-xl bg-slate-50 border-2 border-transparent focus:border-brand-navy focus:bg-white outline-none transition-all placeholder-transparent"
                                        placeholder="Your Name"
                                    />
                                    <label htmlFor="name" className="absolute left-5 top-4 text-slate-400 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-4 peer-placeholder-shown:text-slate-400 peer-focus:-top-2.5 peer-focus:text-xs peer-focus:text-brand-navy peer-focus:bg-white peer-focus:px-1 peer-[:not(:placeholder-shown)]:-top-2.5 peer-[:not(:placeholder-shown)]:text-xs peer-[:not(:placeholder-shown)]:bg-white peer-[:not(:placeholder-shown)]:px-1 cursor-text">Your Name</label>
                                </div>

                                <div className="relative group">
                                    <input 
                                        type="tel" 
                                        id="phone"
                                        required 
                                        className="peer w-full px-5 py-4 rounded-xl bg-slate-50 border-2 border-transparent focus:border-brand-navy focus:bg-white outline-none transition-all placeholder-transparent"
                                        placeholder="Phone Number"
                                    />
                                    <label htmlFor="phone" className="absolute left-5 top-4 text-slate-400 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-4 peer-placeholder-shown:text-slate-400 peer-focus:-top-2.5 peer-focus:text-xs peer-focus:text-brand-navy peer-focus:bg-white peer-focus:px-1 peer-[:not(:placeholder-shown)]:-top-2.5 peer-[:not(:placeholder-shown)]:text-xs peer-[:not(:placeholder-shown)]:bg-white peer-[:not(:placeholder-shown)]:px-1 cursor-text">Phone Number</label>
                                </div>

                                <div className="relative group">
                                    <input 
                                        type="email" 
                                        id="email"
                                        className="peer w-full px-5 py-4 rounded-xl bg-slate-50 border-2 border-transparent focus:border-brand-navy focus:bg-white outline-none transition-all placeholder-transparent"
                                        placeholder="Email (Optional)"
                                    />
                                    <label htmlFor="email" className="absolute left-5 top-4 text-slate-400 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-4 peer-placeholder-shown:text-slate-400 peer-focus:-top-2.5 peer-focus:text-xs peer-focus:text-brand-navy peer-focus:bg-white peer-focus:px-1 peer-[:not(:placeholder-shown)]:-top-2.5 peer-[:not(:placeholder-shown)]:text-xs peer-[:not(:placeholder-shown)]:bg-white peer-[:not(:placeholder-shown)]:px-1 cursor-text">Email (Optional)</label>
                                </div>

                                <div className="relative group">
                                    <textarea 
                                        id="message"
                                        required 
                                        rows={4}
                                        className="peer w-full px-5 py-4 rounded-xl bg-slate-50 border-2 border-transparent focus:border-brand-navy focus:bg-white outline-none transition-all resize-none placeholder-transparent"
                                        placeholder="Message"
                                    />
                                    <label htmlFor="message" className="absolute left-5 top-4 text-slate-400 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-4 peer-placeholder-shown:text-slate-400 peer-focus:-top-2.5 peer-focus:text-xs peer-focus:text-brand-navy peer-focus:bg-white peer-focus:px-1 peer-[:not(:placeholder-shown)]:-top-2.5 peer-[:not(:placeholder-shown)]:text-xs peer-[:not(:placeholder-shown)]:bg-white peer-[:not(:placeholder-shown)]:px-1 cursor-text">Message</label>
                                </div>
                            </div>

                            <button 
                                type="submit"
                                disabled={formStatus === 'submitting'}
                                className="w-full py-5 bg-brand-navy text-white font-bold text-lg rounded-xl shadow-xl shadow-brand-navy/30 hover:bg-blue-900 transition-all flex items-center justify-center gap-3 disabled:opacity-70 disabled:cursor-not-allowed group transform hover:translate-y-[-2px]"
                            >
                                {formStatus === 'submitting' ? (
                                    <span className="animate-pulse">Sending...</span>
                                ) : (
                                    <>
                                        <span>Send Message</span>
                                        <Send size={20} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                                    </>
                                )}
                            </button>
                        </motion.form>
                    )}
                </AnimatePresence>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
};

export default Contact;