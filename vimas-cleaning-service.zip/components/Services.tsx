import React from 'react';
import Reveal from './Reveal';
import { CheckCircle2, ChevronRight } from 'lucide-react';

interface ServiceItem {
  name: string;
  price: string;
  category: "Sofa" | "Chair" | "Mattress";
}

const services: ServiceItem[] = [
  { name: "1-Seater Sofa", price: "RM40", category: "Sofa" },
  { name: "2-Seater Sofa", price: "RM70", category: "Sofa" },
  { name: "3-Seater Sofa", price: "RM90", category: "Sofa" },
  { name: "Small Chair", price: "RM10", category: "Chair" },
  { name: "Medium Chair", price: "RM15", category: "Chair" },
  { name: "Large Chair", price: "RM20", category: "Chair" },
  { name: "Single Mattress (1-part)", price: "RM50", category: "Mattress" },
  { name: "Single Mattress (2-part)", price: "RM90", category: "Mattress" },
  { name: "Queen Mattress (1-part)", price: "RM70", category: "Mattress" },
  { name: "Queen Mattress (2-part)", price: "RM130", category: "Mattress" },
  { name: "King Mattress (1-part)", price: "RM80", category: "Mattress" },
  { name: "King Mattress (2-part)", price: "RM150", category: "Mattress" },
];

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-brand-beige relative overflow-hidden">
      {/* Decorative Wave */}
      <div className="absolute top-0 left-0 w-full overflow-hidden leading-[0]">
        <svg className="relative block w-[calc(100%+1.3px)] h-[50px] md:h-[100px]" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" className="fill-white"></path>
        </svg>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16 mt-8">
          <Reveal>
             <span className="py-1 px-3 rounded-full bg-brand-navy/5 border border-brand-navy/10 text-brand-navy text-xs font-bold tracking-[0.2em] uppercase mb-4 inline-block">
                Transparent Pricing
             </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="text-3xl md:text-5xl font-heading font-bold text-slate-900 mb-4">Our Services & Pricing</h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-slate-600 max-w-2xl mx-auto text-lg font-light">
              No hidden fees. Just high-quality cleaning for every piece of furniture in your home.
            </p>
          </Reveal>
        </div>

        {/* Desktop Table Layout */}
        <div className="hidden md:block max-w-4xl mx-auto bg-white/80 backdrop-blur-md rounded-[2rem] shadow-2xl shadow-slate-200/50 overflow-hidden border border-white/60">
          <div className="grid grid-cols-3 bg-brand-navy text-white p-6 font-bold tracking-widest text-xs uppercase">
            <div className="col-span-2 pl-6">Service</div>
            <div className="text-right pr-6">Price</div>
          </div>
          <div className="divide-y divide-slate-100">
            {services.map((service, index) => (
              <Reveal key={index} delay={index * 0.05} width="100%" direction="none">
                <div className="grid grid-cols-3 p-5 hover:bg-blue-50/60 transition-colors duration-300 group cursor-default relative overflow-hidden">
                  <div className="col-span-2 pl-6 flex items-center gap-4 relative z-10">
                    <div className="w-8 h-8 rounded-full bg-blue-100/50 flex items-center justify-center text-brand-navy opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-50 group-hover:scale-100">
                         <CheckCircle2 size={16} />
                    </div>
                    <span className="font-semibold text-slate-700 group-hover:text-brand-navy transition-colors text-lg -ml-12 group-hover:ml-0 duration-300">{service.name}</span>
                  </div>
                  <div className="text-right pr-6 font-bold text-brand-navy relative z-10 text-lg">{service.price}</div>
                  
                  {/* Subtle hover gradient */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ease-in-out pointer-events-none" />
                </div>
              </Reveal>
            ))}
          </div>
        </div>

        {/* Mobile Card Layout */}
        <div className="md:hidden grid grid-cols-1 gap-4">
          {services.map((service, index) => (
            <Reveal key={index} delay={index * 0.05} direction="up">
              <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex justify-between items-center hover:shadow-lg transition-all active:scale-[0.98]">
                <div className="flex flex-col">
                    <span className="text-[10px] font-bold text-brand-navy/60 uppercase tracking-wider mb-1">{service.category}</span>
                    <h4 className="font-bold text-slate-800 text-base">{service.name}</h4>
                </div>
                <div className="flex items-center gap-3">
                    <div className="text-base font-bold text-brand-navy bg-brand-blue/30 px-3 py-1.5 rounded-lg">
                    {service.price}
                    </div>
                    <ChevronRight size={16} className="text-slate-300" />
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-12 text-center">
            <Reveal delay={0.5}>
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 rounded-full border border-white/50 text-xs md:text-sm text-slate-500 italic">
                    <span className="w-2 h-2 rounded-full bg-brand-navy animate-pulse"></span>
                    Prices may vary slightly depending on condition and requirements.
                </div>
            </Reveal>
        </div>
      </div>
    </section>
  );
};

export default Services;