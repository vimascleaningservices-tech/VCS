import React from 'react';
import { Facebook, Instagram } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-navy text-white pt-16 pb-8">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-8">
          
          {/* Brand */}
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-heading font-bold mb-2">VIMAS CLEANING SERVICE</h2>
            <p className="text-blue-200">Fresh, Clean, and Comfortable Sofas Every Time!</p>
          </div>

          {/* Social Icons */}
          <div className="flex items-center gap-6">
            <a 
              href="https://www.facebook.com/share/1FTbzMnkBh/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white hover:text-brand-navy transition-all duration-300 hover:scale-110"
            >
              <Facebook size={20} />
            </a>
            <a 
              href="https://www.instagram.com/vimas_cleaning_service?igsh=MTRvYjlpb2Rwbmc0bA==" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white hover:text-brand-navy transition-all duration-300 hover:scale-110"
            >
              <Instagram size={20} />
            </a>
            <a 
              href="https://www.tiktok.com/@vimas.cleaning.se?_r=1&_t=ZS-942mS1pjI0H" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white hover:text-brand-navy transition-all duration-300 hover:scale-110"
            >
              <svg 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="w-5 h-5"
              >
                <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
              </svg>
            </a>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 text-center text-sm text-blue-200">
          <p>© 2026 VIMAS CLEANING SERVICE. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;