import React, { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#hero' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Contact', href: '#contact' },
  ];

  const handleNavClick = (href: string) => {
    setIsMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 w-full z-40 transition-all duration-500 ${
        isScrolled 
          ? 'bg-white/85 backdrop-blur-xl shadow-sm border-b border-white/40 py-3' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <a href="#hero" onClick={(e) => { e.preventDefault(); handleNavClick('#hero'); }} className="flex items-center gap-3 group relative z-50">
            {/* Logo Image */}
            <img 
              src="/logo.png" 
              alt="VIMAS CLEANING SERVICE" 
              className="h-10 md:h-14 w-auto object-contain mix-blend-multiply opacity-95 group-hover:opacity-100 transition-opacity"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                e.currentTarget.nextElementSibling?.classList.remove('hidden');
                e.currentTarget.nextElementSibling?.classList.add('flex');
              }}
            />
            {/* Fallback Text Logo (Hidden by default, shown on error) */}
            <div className="hidden flex-col items-start leading-tight">
              <span className="text-xl md:text-2xl font-heading font-bold text-brand-navy tracking-tight">VIMAS</span>
              <span className="text-[0.65rem] md:text-xs font-semibold text-slate-500 tracking-widest uppercase mt-1">Cleaning Service</span>
            </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={(e) => { e.preventDefault(); handleNavClick(link.href); }}
              className="text-sm font-semibold text-slate-700 hover:text-brand-navy transition-colors relative group py-2"
            >
              {link.name}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-brand-navy transition-all duration-300 ease-out group-hover:w-full" />
            </a>
          ))}
          <motion.a
            whileHover={{ scale: 1.05, boxShadow: "0 10px 25px -5px rgba(30, 58, 138, 0.4)" }}
            whileTap={{ scale: 0.95 }}
            href="https://wa.me/60115510571"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-6 py-2.5 bg-brand-navy text-white text-sm font-bold rounded-full hover:bg-blue-900 transition-all shadow-lg shadow-brand-navy/20 cursor-pointer"
          >
            <Phone size={16} className="animate-pulse" />
            <span>Book Now</span>
          </motion.a>
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden p-2 text-slate-800 focus:outline-none bg-white/50 backdrop-blur-sm rounded-lg relative z-50"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={26} /> : <Menu size={26} />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white/95 backdrop-blur-xl border-b border-gray-100 overflow-hidden absolute w-full top-full left-0 shadow-xl z-40"
          >
            <nav className="flex flex-col p-6 gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  className="text-lg font-bold text-slate-800 py-2 border-b border-slate-50"
                  onClick={(e) => { e.preventDefault(); handleNavClick(link.href); }}
                >
                  {link.name}
                </a>
              ))}
              <a
                href="https://wa.me/60115510571"
                className="mt-4 w-full flex items-center justify-center gap-2 px-5 py-4 bg-brand-navy text-white font-bold rounded-xl shadow-lg active:scale-95 transition-transform"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Phone size={20} />
                Book Appointment
              </a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
};

export default Header;