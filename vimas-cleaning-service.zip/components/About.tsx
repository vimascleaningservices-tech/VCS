import React from 'react';
import Reveal from './Reveal';
import { Sparkles, Wind, Gauge, ArrowUpRight } from 'lucide-react';
import { motion } from 'framer-motion';

const features = [
  {
    icon: <Sparkles size={28} />,
    title: "Deep Stain Removal",
    description: "Specialized power agitation breaks down tough food, pet, and spill stains from the fabric fibers.",
    // Online Video URL for immediate playback
    videoSrc: "https://lh3.googleusercontent.com/pw/AP1GczPKHCAQKfHZIbNm0ZoLdtfTs0DvlssJR35COWZJfrwefhkryfsTsJ4wqnzJQENBXpXKFL0DjIYNKxAi6wm7_ozLuDSggA0SZCMBlDxK3FvBuZ_mK-ekNnp2qKF6-nqDK0WKKJ6ZtikALFI7h0HR1VAU_NVbZDZSpNh4HfroYMOSfKECh3E1uAea-Y27ON9-e8N2m-UDsIrbyos0biTIgq5g1Y5TSecy7ZEYI2LGzNvt6j37BwbCdRvmkeiQyPMo0_EH2eeecM8gbbhUBpS-MNYVdQhqftqiGpdVHQp3Gbg0FQjEfsizKN8ckrKEAAu_Eg7_hWnKbdGPo6gJy0gpgNjmI7Sno-depldUVQEXQz9nx0SJx23DI03WOFzOYY99MbVpLvn6xalHICjo7wnbPgOdSuTrof7u1BBTMe0dSYhIE3IezNsv9Ag9cdMFZHen9oiBLCemEV3lcMc_dQD16nfTB4a7lPA8aMPvluEvQ13hZFsXseh8wMNnhbn35hDGF5OFC5SBk6015lrLPPeT6kPY9BHA3560mQ0f0tnaHK-5cUOnicNoPTR40M9RZl6wblx4WTeFlnvHj9_uE09W_cTAWBpM4RxBeaG2IBAUngupsOIU1RrWQ6ex3tBWWV-CxU7ldItwloe0X4E9zolRVROfHP35cD2Pue0JcV4jjAbxlKKkcLDKF34oTgIWhrfdi_PfKS74ttAzPBp_Ys8PXf7n7TmOXI-bSYkDGKahy_TEscBX3ijx4ZCn5zQ-Epc5rsLFpJHpToQZtqLS-7AfPpBOmMehsSQZGkIiTA0dV5oqQYzUuW6RUN9GCYCzt6cGhdfoKDW2H6hPg5eHcykKS_So1feTtbkIDkMmUmzCzLBA1b7vz8dVR8KJ1YA1HPBfgnz4mwW6BHU76h0q3mk3nKJS0BHXURV7dNcliOM5_GuBGEgwCal2deU=m15?authuser=0&cpn=PZIzWlCBpL4wNKUq&c=WEB_EMBEDDED_PLAYER&cver=1.20260216.03.00", 
    fallbackGradient: "from-blue-900 to-slate-900"
  },
  {
    icon: <Wind size={28} />,
    title: "Odor Elimination",
    description: "Neutralize smells at the source with safe misting agents. No masking, just pure freshness.",
    // Online Video URL for immediate playback
    videoSrc: "https://lh3.googleusercontent.com/pw/AP1GczPyxK3kRqSadl93QAK6KhEgHDNilWCfVAajHVqq3qLaIwXb6lVuEOtkg222LBq0_A3NwvlGzm4kt9H8q5dOjk-DV-6O8qvS8Tk9uo2OTdmUkj6uSXGihxxQeWryNZRhIoSIoQNAIgQbJSWH7r8np8mczHyMsJwMmH2AJPkX3bxkZu-AEzZEUj48EwJwMYJNMFiGlra-XQTjaSMgG5raboldhGxA5X4K3duSyaWubZny_iY4mvR5M0R09IVwzlzQKEUcmCqL4OzIZjM20D32A-I32ModVlDCFhG0bJ787XkJF2-D31fo_KFgmkRfilWoreJZMYfLp7htzxW9_JTZ6YiJocya301msO-n3egPqnnX2KaMbNEyKFlzGQoBa6WNG0arLwF80Shcy5tD3GBOg6uuqDtRkmtnhmTp2PE4h2Icl5x4GMULmxwTcTADUeX07F_hj7ayU2EI9JOUa4oUUNxRWca_zCMLxqfqjWLmLFXd1_RS2p0Eq9R0BXVKl0BF2avwK2jiZhk0QI_TIiFDbr-Hv-qy1yzNZOx4GCJYILp7u-7l53JPl35pPxe9JS0TRmwWSGwELGPJNJOo4of1MVuHmtCo_TG9HfzN5L-s_BFYeJrawzyR4ao6nlrxtspMGa95U7_XEIGx4Qz_ob0ADlqkA-JSZBQSr1bkNTdEJxU6GPewOuKu67QM8qF_OfluUUY3ExlYI30HREQHSlbRXSjVHGYJNZUczBCLJxSQJlZWHfua9ZbtBPGgFKpMIZjbiBTiPIs4lnQNwIy_hqvIFVbMjy0mox5zdAF0J8nqOfPleM9dLwaHOZf7CIo36Ad_41tSE3prKgVX9PwUfthq1ThfQrVsIMyCHzUYJLd_eWMQjeFbdFk0sNtnlzketkzwbxxuN8vxdKU--LfwlcbuK1MTdiDXpDDu8NK1ujHvVcdZyaQUNikUnObBbOZO8zucocX86zobBUosPd12IdmBYCjccfXDtyzRsOP9yNzKReuanTU=m15?authuser=0&cpn=Y67LmRQssGxQoYW0&c=WEB_EMBEDDED_PLAYER&cver=1.20260216.03.00", 
    fallbackGradient: "from-purple-900 to-slate-900"
  },
  {
    icon: <Gauge size={28} />,
    title: "Industrial Extraction",
    description: "High-power suction extraction pulls out deep-seated dust, mites, and dirty water instantly.",
    // Online Video URL for immediate playback
    videoSrc: "https://lh3.googleusercontent.com/pw/AP1GczOjvtjmSzrCdn4LUQHTWTpn2v6REgZEzP7AK8SkPg6TDkc97a7y_2cT7slDhGMwUjipTdSU0tC8w7VJ8QbZFDCuR343jUhMd1tGWiCQpWJQYeooNmFT4-8UtL3gLKZSCfwcBJpiyJ0jMW7I2l-Qp1GWsvgmztUF0OHTBK5olVBNA5WTvu3Ojq-_7BwZThhfns13D7bsFUdue4rvseCo1vAsWk2QfwKRj5pbgqypPlwoQUPpkAsUBXKohhcE4z3a0QgYJl6O6tbtCYt1ZAE5pgtJyLsGc9_gwy6yCBRSqwzfhinoQw1DjwSfkEU0lS81tjRhRFTPoINbZUxoDonc_NQrPePWy2qG9VXLeOz-rdVQwQWprKPzTFc_YWHZTgGAWW0-MHzbn-KV6qH6mSKwxUa6jsn5E37vOWDlDmbt2eToy4aNtoRNZmibE70gBTzt1Hxuj1g43wtW6eHlEluO4DaWPxdC4Yuc8wlWCs8IoSyDfoLTkvbNRuFgwGUOGP6BDoBc5ijUTrltIezw6S9fzDLh5vAAymlQHVIAUgdkMCmivTAH1ZZIidmk4E_TVK0FVERBT0hVXfh759w4wLDvDgP2uvFvlW_TcKXnO5aFT7GY4fbq15d9Q6yLjb3luSVF-vvEvoIhG4CTZolSdAz7mNkCXQb8Rk_0Zg44kWi6Q3seQ8l2V4wJtkdQFqUQ9uLU3v5bd1KYkPjiC6At58LiB_Ur27UPPp7iaS4Wisxl2DCrcjPeT3LAsmkRfYJWrxPxduRqyTK7DHAFklKt5a4GAxpUxiDQErE_3CNDbfn0SOM4-nwCtI1x9lq08kGWyAc6652rdbk8aUR4Lsue-r6C5b1KTiMMGSuOZfKqqOTJbn8ri7hhE49Z_uqkQl6akYD-4WIUzSKVvgAN0bVHcZiWg9l3FiijXt14470nvmRR9Jl8CIBpXR1mBRQ=m15?authuser=0&cpn=qDKnwjZFv-c_fGPi&c=WEB_EMBEDDED_PLAYER&cver=1.20260216.03.00", 
    fallbackGradient: "from-indigo-900 to-slate-900"
  }
];

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-white relative z-20 overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand-blue/10 rounded-full blur-[120px] -z-10" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-brand-beige/50 rounded-full blur-[120px] -z-10" />

      <div className="container mx-auto px-6">
        
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-20">
          <Reveal>
            <div className="inline-block mb-4">
                <span className="py-1 px-3 rounded-full bg-brand-navy/5 border border-brand-navy/10 text-brand-navy text-xs font-bold tracking-[0.2em] uppercase">
                    Why Choose Us
                </span>
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <h3 className="text-4xl md:text-5xl font-heading font-bold text-slate-900 mb-6">Restoring Freshness & Comfort</h3>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="text-lg md:text-xl text-slate-600 leading-relaxed font-light max-w-2xl mx-auto">
              We are a trusted professional sofa cleaning service based in <strong className="text-brand-navy font-semibold">Klang</strong>. 
              Our industrial-grade process revitalizes your furniture, leaving it hygienic and looking like new.
            </p>
          </Reveal>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Reveal key={index} delay={0.2 + index * 0.15} direction="up" className="h-full">
              <motion.div 
                whileHover="hover"
                initial="initial"
                className="relative h-[450px] rounded-[2rem] overflow-hidden group shadow-2xl shadow-slate-200 cursor-default isolate transform-gpu bg-slate-900"
              >
                {/* Video Layer */}
                <motion.div 
                    variants={{
                        initial: { scale: 1 },
                        hover: { scale: 1.1 }
                    }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="absolute inset-0"
                >
                  {/* Fallback background if video missing */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${feature.fallbackGradient}`} />
                  
                  <video 
                    autoPlay 
                    loop 
                    muted 
                    playsInline 
                    className="absolute inset-0 w-full h-full object-cover opacity-60"
                  >
                    <source src={feature.videoSrc} type="video/mp4" />
                  </video>
                </motion.div>

                {/* Dark Overlay for Text Readability */}
                <div className="absolute inset-0 bg-slate-900/50" />
                
                {/* Gradient Bottom Up */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent opacity-90" />
                
                {/* Subtle Inner Border */}
                <div className="absolute inset-0 rounded-[2rem] border border-white/10 pointer-events-none" />

                {/* Content */}
                <div className="absolute inset-0 p-8 flex flex-col justify-end text-white z-10">
                  <motion.div 
                    variants={{
                        initial: { y: 0, scale: 1 },
                        hover: { y: -10, scale: 1.05 }
                    }}
                    transition={{ duration: 0.4 }}
                    className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center mb-6 shadow-lg text-white"
                  >
                    {feature.icon}
                  </motion.div>
                  
                  <motion.h4 
                    variants={{
                        initial: { y: 0 },
                        hover: { y: -5 }
                    }}
                    transition={{ duration: 0.4 }}
                    className="text-2xl font-bold font-heading mb-3"
                  >
                    {feature.title}
                  </motion.h4>
                  
                  <motion.p 
                    variants={{
                        initial: { opacity: 0.9, y: 0 },
                        hover: { opacity: 1, y: -5 }
                    }}
                    transition={{ duration: 0.4 }}
                    className="text-white/90 leading-relaxed text-sm md:text-base mb-6 font-medium"
                  >
                    {feature.description}
                  </motion.p>

                  <motion.div 
                    variants={{
                        initial: { width: "40px", opacity: 0.5 },
                        hover: { width: "100%", opacity: 1 }
                    }}
                    transition={{ duration: 0.6 }}
                    className="h-[3px] bg-brand-blue/50 rounded-full" 
                  />
                </div>

                {/* Corner Accent */}
                <div className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-500 translate-y-2 group-hover:translate-y-0 border border-white/20">
                   <ArrowUpRight size={20} className="text-white" />
                </div>
              </motion.div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;