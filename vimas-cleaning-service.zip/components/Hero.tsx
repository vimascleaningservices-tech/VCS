import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, Star, CheckCircle2, ShieldCheck } from 'lucide-react';
import Reveal from './Reveal';

const Hero: React.FC = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);
  const y2 = useTransform(scrollY, [0, 500], [0, -150]);
  const opacity = useTransform(scrollY, [0, 400], [1, 0]);

  const scrollToServices = (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.getElementById('services');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="relative w-full min-h-[110vh] md:min-h-screen flex items-center justify-center overflow-hidden pt-24 pb-12 md:pt-20 md:pb-0">
      {/* Background Decor - Lower z-index to prevents blocking clicks */}
      <div className="absolute inset-0 w-full h-full pointer-events-none z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-brand-beige via-[#fffbf5] to-brand-blue/20" />
        
        {/* Animated Shapes */}
        <motion.div 
          style={{ y: y1 }}
          className="absolute top-[-10%] right-[-5%] w-[600px] h-[600px] bg-brand-blue/30 rounded-full blur-[120px] mix-blend-multiply" 
        />
        <motion.div 
          style={{ y: y2 }}
          className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-indigo-100/60 rounded-full blur-[100px] mix-blend-multiply" 
        />
      </div>

      <div className="container mx-auto px-6 relative z-10 flex flex-col md:flex-row items-center gap-12 lg:gap-20">
        
        {/* Text Content */}
        <div className="flex-1 text-center md:text-left pt-8 md:pt-0 relative z-20 pointer-events-none">
          <div className="pointer-events-auto">
            <Reveal delay={0.1}>
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-brand-navy/10 text-brand-navy text-xs font-bold uppercase tracking-widest shadow-sm mb-8 hover:scale-105 transition-transform cursor-default">
                <Star size={12} className="fill-brand-navy" />
                <span>Premium Cleaning Service</span>
              </div>
            </Reveal>

            <Reveal delay={0.2}>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-heading font-bold text-slate-900 leading-[1.1] mb-6 tracking-tight">
                Professional <br />
                <span className="text-brand-navy relative inline-block">
                  Sofa Cleaning
                  <svg className="absolute w-full h-3 -bottom-1 left-0 text-brand-blue -z-10 opacity-60" viewBox="0 0 100 10" preserveAspectRatio="none">
                     <path d="M0 5 Q 50 10 100 5" stroke="currentColor" strokeWidth="8" fill="none" />
                  </svg>
                </span>
                <br /> in Klang
              </h1>
            </Reveal>

            <Reveal delay={0.3}>
              <p className="text-lg md:text-xl text-slate-600 mb-10 max-w-lg mx-auto md:mx-0 leading-relaxed font-medium">
                Deep clean for stains, dust & odors using safe solutions and industrial-grade extraction machines. Restore comfort to your home today.
              </p>
            </Reveal>
          </div>

          <Reveal delay={0.4}>
            {/* High Z-Index for buttons to ensure they work */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start items-center relative z-[100] pointer-events-auto">
              <motion.a 
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                href="https://wa.me/60115510571"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-8 py-4 bg-brand-navy text-white text-base font-bold rounded-full shadow-xl shadow-brand-navy/30 flex items-center justify-center gap-3 hover:bg-blue-900 transition-all ring-4 ring-transparent hover:ring-brand-blue/30 cursor-pointer"
              >
                <span>Book Now on WhatsApp</span>
                <ArrowRight size={18} />
              </motion.a>
              
              <motion.a 
                whileHover={{ scale: 1.02, y: -2, backgroundColor: "rgba(255,255,255,1)" }}
                whileTap={{ scale: 0.98 }}
                onClick={scrollToServices}
                href="#services"
                className="w-full sm:w-auto px-8 py-4 bg-white/60 backdrop-blur-md border border-brand-navy/10 text-brand-navy text-base font-bold rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center cursor-pointer"
              >
                View Prices
              </motion.a>
            </div>
          </Reveal>

          <div className="pointer-events-auto">
            <Reveal delay={0.5}>
              <div className="mt-10 flex items-center justify-center md:justify-start gap-6 text-sm font-semibold text-slate-500">
                 <div className="flex items-center gap-2">
                   <CheckCircle2 size={16} className="text-green-500" />
                   <span>Safe Solutions</span>
                 </div>
                 <div className="flex items-center gap-2">
                   <CheckCircle2 size={16} className="text-green-500" />
                   <span>Klang Valley</span>
                 </div>
              </div>
            </Reveal>
          </div>
        </div>

        {/* Hero Visual - Premium Sofa Card */}
        <div className="flex-1 relative w-full flex items-center justify-center lg:justify-end z-10 pointer-events-none">
            <motion.div 
                initial={{ opacity: 0, x: 50, rotate: 2 }}
                animate={{ opacity: 1, x: 0, rotate: 0 }}
                transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
                style={{ opacity }}
                className="relative z-10 w-full max-w-[500px]"
            >
                {/* Main Image Card */}
                <div className="relative aspect-[4/3] rounded-[2.5rem] overflow-hidden shadow-2xl shadow-brand-navy/20 border-4 border-white group">
                     {/* Sofa Image Background - ONLINE URL RESTORED */}
                     <div 
                        className="absolute inset-0 bg-cover bg-center transition-transform duration-[10s] group-hover:scale-110 ease-linear"
                        style={{ backgroundImage: `url("https://photos.fife.usercontent.google.com/pw/AP1GczP-71mJA6KwRjudo4OK2LnY1sP0zZ-WYHC4ZHNXa13LcgpNn_vVdgQM=w1436-h947-s-no-gm?authuser=0")` }}
                     >
                       {/* Fallback color */}
                       <div className="absolute inset-0 bg-slate-200 -z-10" />
                     </div>
                     
                     {/* Overlay Gradient */}
                     <div className="absolute inset-0 bg-gradient-to-t from-brand-navy/90 via-brand-navy/10 to-transparent opacity-80" />

                     {/* Card Content */}
                     <div className="absolute bottom-0 left-0 w-full p-8 text-white">
                        <div className="flex items-center gap-3 mb-2">
                            <div className="bg-green-500 text-white p-1.5 rounded-full shadow-lg shadow-green-500/40">
                                <ShieldCheck size={20} />
                            </div>
                            <span className="text-sm font-bold uppercase tracking-wider text-green-300">Guaranteed Quality</span>
                        </div>
                        <h3 className="text-2xl md:text-3xl font-heading font-bold mb-1 shadow-black/10 drop-shadow-lg">
                            100% Satisfaction
                        </h3>
                        <p className="text-blue-100 text-sm md:text-base font-medium opacity-90">
                            We bring your furniture back to life.
                        </p>
                     </div>
                </div>

                {/* Floating Badge */}
                <motion.div 
                   initial={{ y: 20, opacity: 0 }}
                   animate={{ y: 0, opacity: 1 }}
                   transition={{ delay: 0.6 }}
                   className="absolute -top-6 -right-4 md:right-8 bg-white/90 backdrop-blur-xl p-4 pr-6 rounded-2xl shadow-xl border border-white flex items-center gap-4 animate-float"
                >
                    <div className="w-12 h-12 bg-brand-blue rounded-xl flex items-center justify-center text-brand-navy">
                        <Star size={24} className="fill-brand-navy" />
                    </div>
                    <div>
                        <div className="text-2xl font-bold text-slate-800 leading-none">5.0</div>
                        <div className="text-xs text-slate-500 font-bold uppercase mt-1">Star Rating</div>
                    </div>
                </motion.div>
            </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;