import React, { useEffect, useRef } from 'react';
import { motion, useInView, useAnimation, Variants } from 'framer-motion';

interface RevealProps {
  children: React.ReactNode;
  width?: "fit-content" | "100%";
  delay?: number;
  duration?: number;
  direction?: "up" | "down" | "left" | "right" | "none";
  className?: string;
}

const Reveal: React.FC<RevealProps> = ({ 
  children, 
  width = "100%", 
  delay = 0.25, 
  duration = 0.5,
  direction = "up",
  className = ""
}) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-10% 0px -10% 0px" });
  const mainControls = useAnimation();

  useEffect(() => {
    if (isInView) {
      mainControls.start("visible");
    }
  }, [isInView, mainControls]);

  const getVariants = (): Variants => {
    const distance = 75;
    let initial = {};
    
    switch(direction) {
      case "up": initial = { opacity: 0, y: distance }; break;
      case "down": initial = { opacity: 0, y: -distance }; break;
      case "left": initial = { opacity: 0, x: distance }; break;
      case "right": initial = { opacity: 0, x: -distance }; break;
      case "none": initial = { opacity: 0, scale: 0.95 }; break;
      default: initial = { opacity: 0, y: distance };
    }

    return {
      hidden: initial,
      visible: { 
        opacity: 1, 
        y: 0, 
        x: 0, 
        scale: 1,
        transition: { duration, delay, ease: "easeOut" } 
      },
    };
  };

  return (
    <div ref={ref} style={{ position: "relative", width }} className={className}>
      <motion.div
        variants={getVariants()}
        initial="hidden"
        animate={mainControls}
      >
        {children}
      </motion.div>
    </div>
  );
};

export default Reveal;